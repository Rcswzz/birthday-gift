const cloudbase = require("@cloudbase/node-sdk");

const app = cloudbase.init({ env: cloudbase.SYMBOL_CURRENT_ENV });
const db = app.database();

const headers = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json"
};

exports.main = async (event, context) => {
  const method = (context && (context.httpMethod || (context.request && context.request.method))) || "POST";
  if (method === "OPTIONS") {
    return { statusCode: 204, headers };
  }

  let data = event;
  try {
    if (event && typeof event === "object" && event.body) {
      data = typeof event.body === "string" ? JSON.parse(event.body) : event.body;
    }
  } catch (e) {}

  const info = { env: process.env.TCB_ENV || "unknown" };

  try {
    // 强制确保集合存在（已存在时会报"已存在"错误，忽略即可）
    try {
      await db.createCollection("gift_choice");
      info.created = true;
    } catch (e) {
      info.createError = e.message;
    }

    const doc = {
      type: data.type || "gift",
      category: data.category || "",
      giftId: data.giftId || "",
      giftName: data.giftName || "",
      message: data.message || "",
      submittedAt: data.submittedAt || new Date().toISOString()
    };

    let res;
    try {
      res = await db.collection("gift_choice").add({ data: doc });
    } catch (e1) {
      info.addError1 = e1.message;
      res = await db.collection("gift_choice").add(doc);
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ ok: true, id: (res && res.id) || null, info })
    };
  } catch (e) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ ok: false, error: e.message, info })
    };
  }
};
